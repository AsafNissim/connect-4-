package com.example.asafproject;

public class Disk {
}
