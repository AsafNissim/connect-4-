package com.example.asafproject;

public class BoardGame extends View{

}
